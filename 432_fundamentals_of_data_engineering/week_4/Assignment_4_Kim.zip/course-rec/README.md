# www-phone
A Phone Book application that works with HTTP

- `go run *.go`

