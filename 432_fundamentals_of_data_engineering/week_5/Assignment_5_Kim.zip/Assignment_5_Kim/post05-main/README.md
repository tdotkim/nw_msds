# post05
Working with PostgreSQL DB in Go

Create tables by running the next command:

`$ psql -h localhost -p 5432 -U mtsouk master < create_tables.sql`
